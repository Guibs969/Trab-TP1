var class_email =
[
    [ "getValor", "class_email.html#a58a3acf741ef61bcae302f7a323f6904", null ],
    [ "setValor", "class_email.html#ae097bf788f3789ad00f52f29794786dc", null ]
];