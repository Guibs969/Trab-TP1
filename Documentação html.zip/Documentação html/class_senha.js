var class_senha =
[
    [ "getValor", "class_senha.html#acc03ecddb9a26f8b07fb8bb079f4e055", null ],
    [ "setValor", "class_senha.html#a76fdfa76064ff7ad60dffa7ddb6a9e8f", null ]
];