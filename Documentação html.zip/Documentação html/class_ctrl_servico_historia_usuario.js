var class_ctrl_servico_historia_usuario =
[
    [ "alterarEstado", "class_ctrl_servico_historia_usuario.html#a316a8418aad2d3ab71d68dc09c9df83b", null ],
    [ "atribuirDesenvolvedor", "class_ctrl_servico_historia_usuario.html#a27058346524b9c1018c33a4092e67b90", null ],
    [ "atualizar", "class_ctrl_servico_historia_usuario.html#a5a7f760daa715ddf39fc71565e88ad77", null ],
    [ "buscar", "class_ctrl_servico_historia_usuario.html#a053ceadf8987c4d2fc11f9edb3a37589", null ],
    [ "cadastrar", "class_ctrl_servico_historia_usuario.html#a6232553835083ceb852da7423927572e", null ],
    [ "excluir", "class_ctrl_servico_historia_usuario.html#aa3d7919523b4deabe0e24abbe9cccc9f", null ],
    [ "existe", "class_ctrl_servico_historia_usuario.html#a4d8c7b197253abc60eea34ccc2d205ff", null ],
    [ "listar", "class_ctrl_servico_historia_usuario.html#af0172ca7f8fa1cc962c981f47431166d", null ],
    [ "listarPorPessoa", "class_ctrl_servico_historia_usuario.html#a12ed62441eeff9c72221a4bd32cde529", null ],
    [ "listarPorPlano", "class_ctrl_servico_historia_usuario.html#a8f1de3ab5d67415ea352ad57ab3ae7c6", null ],
    [ "listarPorProjeto", "class_ctrl_servico_historia_usuario.html#a9dfa0981bc78aace401e40047cc56fb5", null ],
    [ "removerDesenvolvedor", "class_ctrl_servico_historia_usuario.html#ada56b1f359779719a535d89d051d6d15", null ]
];