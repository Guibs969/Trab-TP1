var class_texto =
[
    [ "getValor", "class_texto.html#a3e10c490166ff82e6559a502fe790b2c", null ],
    [ "setValor", "class_texto.html#a5388dd04048c39496dc1e64f710ef1cd", null ]
];