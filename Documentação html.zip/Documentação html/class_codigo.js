var class_codigo =
[
    [ "getValor", "class_codigo.html#a42f4ee541458441b438bb4b0c9cc3921", null ],
    [ "setValor", "class_codigo.html#a41dc7e53e56e38c9a174cede4be1d3cc", null ]
];