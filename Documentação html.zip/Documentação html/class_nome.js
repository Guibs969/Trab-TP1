var class_nome =
[
    [ "getValor", "class_nome.html#ae6eddd41a782357f0466a1c400156925", null ],
    [ "setValor", "class_nome.html#acc1f90c7abfda00af4f00d9cd37a625a", null ]
];