var class_data =
[
    [ "getValor", "class_data.html#aecd8f0d04b834d1448d1d005f9b748b8", null ],
    [ "setValor", "class_data.html#ab9423a2754e88ee6bfbe15e389f0ac4c", null ]
];