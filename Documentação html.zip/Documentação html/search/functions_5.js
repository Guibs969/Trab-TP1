var searchData=
[
  ['setacao_0',['setAcao',['../class_historia_de_usuario.html#aab7aeabd6ed310fcd7c065daac70151f',1,'HistoriaDeUsuario']]],
  ['setcapacidade_1',['setCapacidade',['../class_plano_de_sprint.html#ae3d25010275acc531274eda503ec1c33',1,'PlanoDeSprint']]],
  ['setcodigo_2',['setCodigo',['../class_historia_de_usuario.html#a7b7a8b6070f7405a149b5207a8de720b',1,'HistoriaDeUsuario::setCodigo()'],['../class_plano_de_sprint.html#a5e43c9da3b821e029055f6e4d824f52c',1,'PlanoDeSprint::setCodigo()']]],
  ['setcodigoprojeto_3',['setCodigoProjeto',['../class_historia_de_usuario.html#ab35d8cff4c68ae2b2b4dbb3fb67391f1',1,'HistoriaDeUsuario::setCodigoProjeto()'],['../class_plano_de_sprint.html#a49d45fe2c13d193db8a260be22e9ef45',1,'PlanoDeSprint::setCodigoProjeto()']]],
  ['setemail_4',['setEmail',['../class_pessoa.html#a07c9dc9687e897de901a0361cdae0401',1,'Pessoa']]],
  ['setestado_5',['setEstado',['../class_historia_de_usuario.html#ab474655beab5b02759111dcee1faaa2e',1,'HistoriaDeUsuario']]],
  ['setestimativa_6',['setEstimativa',['../class_historia_de_usuario.html#af450df77612e06df49401636b21601b9',1,'HistoriaDeUsuario']]],
  ['setnome_7',['setNome',['../class_pessoa.html#afddbfe1fabc8e39b53f9b59b24702591',1,'Pessoa']]],
  ['setobjetivo_8',['setObjetivo',['../class_plano_de_sprint.html#ada377021029a43d602e72370bb7e9503',1,'PlanoDeSprint']]],
  ['setpapel_9',['setPapel',['../class_historia_de_usuario.html#ab8cba0ed537f0332800aca0498d8b67d',1,'HistoriaDeUsuario::setPapel()'],['../class_pessoa.html#af9fd246c333ffb8c8deef7a4c00fed68',1,'Pessoa::setPapel()']]],
  ['setprioridade_10',['setPrioridade',['../class_historia_de_usuario.html#ae469900db4b1677a31eb966ff0f0b955',1,'HistoriaDeUsuario']]],
  ['setsenha_11',['setSenha',['../class_pessoa.html#a57ed4246933f9585fc92a4adf9e1f69f',1,'Pessoa']]],
  ['setservicopessoa_12',['setServicoPessoa',['../class_ctrl_apresentacao_pessoa.html#a89d06482d5368754a104e4859b509e9a',1,'CtrlApresentacaoPessoa']]],
  ['settitulo_13',['setTitulo',['../class_historia_de_usuario.html#afa61720731c9bf2f9eebdfee14fef78a',1,'HistoriaDeUsuario']]],
  ['setvalor_14',['setValor',['../class_codigo.html#a41dc7e53e56e38c9a174cede4be1d3cc',1,'Codigo::setValor()'],['../class_data.html#ab9423a2754e88ee6bfbe15e389f0ac4c',1,'Data::setValor()'],['../class_email.html#ae097bf788f3789ad00f52f29794786dc',1,'Email::setValor()'],['../class_estado.html#a33a4a941d8b83306f6793af42ed8ce66',1,'Estado::setValor()'],['../class_nome.html#acc1f90c7abfda00af4f00d9cd37a625a',1,'Nome::setValor()'],['../class_papel.html#a5b238a371095504639ba852f349ec1e4',1,'Papel::setValor()'],['../class_prioridade.html#aad6b4a4481ac4b9096b7788b3b228e64',1,'Prioridade::setValor()'],['../class_senha.html#a76fdfa76064ff7ad60dffa7ddb6a9e8f',1,'Senha::setValor()'],['../class_tempo.html#a518d897c54d724f2e2571451fda2b787',1,'Tempo::setValor()'],['../class_texto.html#a5388dd04048c39496dc1e64f710ef1cd',1,'Texto::setValor()'],['../class_historia_de_usuario.html#a798877ec1aa80ca2975d8203e2981fff',1,'HistoriaDeUsuario::setValor()']]]
];
