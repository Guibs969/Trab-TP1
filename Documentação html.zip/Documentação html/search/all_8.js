var searchData=
[
  ['getacao_0',['getAcao',['../class_historia_de_usuario.html#af230f6c4f5c152054a35f6cd9a7be4e2',1,'HistoriaDeUsuario']]],
  ['getcapacidade_1',['getCapacidade',['../class_plano_de_sprint.html#a9a338492f7d18dada39014fd5c355cf4',1,'PlanoDeSprint']]],
  ['getcodigo_2',['getCodigo',['../class_historia_de_usuario.html#a6ad31554e3fe68d6fb5b5e95996abc7d',1,'HistoriaDeUsuario::getCodigo()'],['../class_plano_de_sprint.html#ac2381fe1f2101f4982119a007573f67d',1,'PlanoDeSprint::getCodigo()'],['../class_projeto.html#a5d9c3bb6177e5c62176347461bd620a3',1,'Projeto::getCodigo()']]],
  ['getcodigoprojeto_3',['getCodigoProjeto',['../class_historia_de_usuario.html#ac5da7d08259f03d106c4c15238cc0596',1,'HistoriaDeUsuario::getCodigoProjeto()'],['../class_plano_de_sprint.html#adc38c2a64cb4c7c18da376305737064b',1,'PlanoDeSprint::getCodigoProjeto()']]],
  ['getdesenvolvedor_4',['getDesenvolvedor',['../class_historia_de_usuario.html#ab42d45313917c00dfbf949d31e3618cd',1,'HistoriaDeUsuario']]],
  ['getemail_5',['getEmail',['../class_pessoa.html#a137a2a665a10ffa4880d1f7d726b07c7',1,'Pessoa']]],
  ['getestado_6',['getEstado',['../class_historia_de_usuario.html#a727847b88582b3d9279b0c441959c8d7',1,'HistoriaDeUsuario']]],
  ['getestimativa_7',['getEstimativa',['../class_historia_de_usuario.html#a5d0c719d66cfb7e5162e65490a508645',1,'HistoriaDeUsuario']]],
  ['gethistorias_8',['getHistorias',['../class_plano_de_sprint.html#a8f906687fd123a2072cb3e835a0cdd62',1,'PlanoDeSprint::getHistorias()'],['../class_projeto.html#af8fe1e0455196a23acfe9abd22f039b7',1,'Projeto::getHistorias() const']]],
  ['getinicio_9',['getInicio',['../class_projeto.html#ae68dfbb815e8a85340590eacc683e574',1,'Projeto']]],
  ['getmestrescrum_10',['getMestreScrum',['../class_projeto.html#a430aa302c35aad9b50184c665a594b1d',1,'Projeto']]],
  ['getnome_11',['getNome',['../class_pessoa.html#ad0c0448768ca2f5b5dfca86f156cdfe9',1,'Pessoa::getNome()'],['../class_projeto.html#a1eb1c0d356d0f662ac6fda75ff766004',1,'Projeto::getNome()']]],
  ['getobjetivo_12',['getObjetivo',['../class_plano_de_sprint.html#a790aceecf2c79a63b974e97f1c04774f',1,'PlanoDeSprint']]],
  ['getpapel_13',['getPapel',['../class_historia_de_usuario.html#ad9343d6144e0ebce21af61e1356d63da',1,'HistoriaDeUsuario::getPapel()'],['../class_pessoa.html#a8c7e1938888e9e84b5c30ca977b98b9d',1,'Pessoa::getPapel()']]],
  ['getplanos_14',['getPlanos',['../class_projeto.html#a619ceb2e1b8818e462ebe95bc33fa2dc',1,'Projeto']]],
  ['getprioridade_15',['getPrioridade',['../class_historia_de_usuario.html#a72f835badb163e3202c71f8e3aa1e09b',1,'HistoriaDeUsuario']]],
  ['getproprietario_16',['getProprietario',['../class_projeto.html#a8e182dc90d52121b1851be1729664edf',1,'Projeto']]],
  ['getsenha_17',['getSenha',['../class_pessoa.html#a02498f338ca00cdd18e794f17d660281',1,'Pessoa']]],
  ['gettermino_18',['getTermino',['../class_projeto.html#aaa3ccd83ad23021458cac35b74683168',1,'Projeto']]],
  ['gettitulo_19',['getTitulo',['../class_historia_de_usuario.html#ac94e47e85a0641bdffa8fac83a9aed3d',1,'HistoriaDeUsuario']]],
  ['getvalor_20',['getValor',['../class_codigo.html#a42f4ee541458441b438bb4b0c9cc3921',1,'Codigo::getValor()'],['../class_data.html#aecd8f0d04b834d1448d1d005f9b748b8',1,'Data::getValor()'],['../class_email.html#a58a3acf741ef61bcae302f7a323f6904',1,'Email::getValor()'],['../class_estado.html#a5bd675fc2714dd7973602ead64895038',1,'Estado::getValor()'],['../class_nome.html#ae6eddd41a782357f0466a1c400156925',1,'Nome::getValor()'],['../class_papel.html#a2f3d568dc6ddf7037c109f73f0726d72',1,'Papel::getValor()'],['../class_prioridade.html#a0e8b94a8c528835653a59415ff437965',1,'Prioridade::getValor()'],['../class_senha.html#acc03ecddb9a26f8b07fb8bb079f4e055',1,'Senha::getValor()'],['../class_tempo.html#a92c28d0b24dfd8a68cbf7eba07448fb4',1,'Tempo::getValor()'],['../class_texto.html#a3e10c490166ff82e6559a502fe790b2c',1,'Texto::getValor()'],['../class_historia_de_usuario.html#a1081ce46124f6ec015eb871a5ebd0cb9',1,'HistoriaDeUsuario::getValor()']]]
];
