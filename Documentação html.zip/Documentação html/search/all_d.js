var searchData=
[
  ['removerdesenvolvedor_0',['removerDesenvolvedor',['../class_historia_de_usuario.html#ae02b97a8eec76b22d2b43c3fbfc1a670',1,'HistoriaDeUsuario']]],
  ['removerhistoria_1',['removerHistoria',['../class_plano_de_sprint.html#a4bac85d5631c53d735ac54296c160fa5',1,'PlanoDeSprint']]]
];
