var searchData=
[
  ['adicionarhistoria_0',['adicionarHistoria',['../class_plano_de_sprint.html#a592687b4da2eebde1939888c3b93c081',1,'PlanoDeSprint']]],
  ['atribuirdesenvolvedor_1',['atribuirDesenvolvedor',['../class_historia_de_usuario.html#a7fe012e1c7169751b20c92749aeee266',1,'HistoriaDeUsuario']]]
];
