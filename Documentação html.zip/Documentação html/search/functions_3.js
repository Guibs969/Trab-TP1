var searchData=
[
  ['possuidesenvolvedor_0',['possuiDesenvolvedor',['../class_historia_de_usuario.html#a78692cfd6bad49a605c77a018ba891ab',1,'HistoriaDeUsuario']]]
];
