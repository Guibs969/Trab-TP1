var searchData=
[
  ['removerdesenvolvedor_0',['removerDesenvolvedor',['../class_historia_de_usuario.html#ae02b97a8eec76b22d2b43c3fbfc1a670',1,'HistoriaDeUsuario::removerDesenvolvedor()'],['../class_i_servico_historia_usuario.html#a65212c2ad25f293ac40180c9c6247325',1,'IServicoHistoriaUsuario::removerDesenvolvedor()'],['../class_ctrl_servico_historia_usuario.html#ada56b1f359779719a535d89d051d6d15',1,'CtrlServicoHistoriaUsuario::removerDesenvolvedor()']]],
  ['removerhistoria_1',['removerHistoria',['../class_plano_de_sprint.html#a4bac85d5631c53d735ac54296c160fa5',1,'PlanoDeSprint']]]
];
