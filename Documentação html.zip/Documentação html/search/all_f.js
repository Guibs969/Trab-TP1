var searchData=
[
  ['tempo_0',['Tempo',['../class_tempo.html',1,'']]],
  ['texto_1',['Texto',['../class_texto.html',1,'']]],
  ['trabalho_20prático_201_20modelagem_20c_2',['Trabalho Prático 1 - Modelagem C++',['../dir_7306f8e14b87ea2c3c3a52f1d638c8f2.html#autotoc_md0',1,'']]]
];
