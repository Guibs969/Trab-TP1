var searchData=
[
  ['adicionarhistoria_0',['adicionarHistoria',['../class_plano_de_sprint.html#a592687b4da2eebde1939888c3b93c081',1,'PlanoDeSprint']]],
  ['arquitetura_20módulos_20em_20camadas_1',['2. Diagrama de Arquitetura (Módulos em Camadas)',['../dir_7306f8e14b87ea2c3c3a52f1d638c8f2.html#autotoc_md5',1,'']]],
  ['atribuirdesenvolvedor_2',['atribuirDesenvolvedor',['../class_historia_de_usuario.html#a7fe012e1c7169751b20c92749aeee266',1,'HistoriaDeUsuario']]]
];
