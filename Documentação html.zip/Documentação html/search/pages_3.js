var searchData=
[
  ['arquitetura_20módulos_20em_20camadas_0',['2. Diagrama de Arquitetura (Módulos em Camadas)',['../dir_fa43ab4efcc759b9afd14d048b2bc958.html#autotoc_md5',1,'']]]
];
