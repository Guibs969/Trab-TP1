var searchData=
[
  ['arquitetura_20módulos_20em_20camadas_0',['2. Diagrama de Arquitetura (Módulos em Camadas)',['../dir_7306f8e14b87ea2c3c3a52f1d638c8f2.html#autotoc_md5',1,'']]]
];
