var hierarchy =
[
    [ "Codigo", "class_codigo.html", null ],
    [ "ContainerHistoriaUsuario", "class_container_historia_usuario.html", null ],
    [ "ContainerPessoa", "class_container_pessoa.html", null ],
    [ "ContainerPlanoSprint", "class_container_plano_sprint.html", null ],
    [ "ContainerProjeto", "class_container_projeto.html", null ],
    [ "Data", "class_data.html", null ],
    [ "Email", "class_email.html", null ],
    [ "Estado", "class_estado.html", null ],
    [ "HistoriaDeUsuario", "class_historia_de_usuario.html", null ],
    [ "IApresentacaoPessoa", null, [
      [ "CtrlApresentacaoPessoa", "class_ctrl_apresentacao_pessoa.html", null ]
    ] ],
    [ "IApresentacaoSistema", "class_i_apresentacao_sistema.html", [
      [ "CtrlApresentacaoSistema", "class_ctrl_apresentacao_sistema.html", null ]
    ] ],
    [ "IServicoHistoriaUsuario", "class_i_servico_historia_usuario.html", [
      [ "CtrlServicoHistoriaUsuario", "class_ctrl_servico_historia_usuario.html", null ]
    ] ],
    [ "IServicoPessoa", "class_i_servico_pessoa.html", [
      [ "CtrlServicoPessoa", "class_ctrl_servico_pessoa.html", null ]
    ] ],
    [ "IServicoPlanoSprint", "class_i_servico_plano_sprint.html", [
      [ "CtrlServicoPlanoSprint", "class_ctrl_servico_plano_sprint.html", null ]
    ] ],
    [ "IServicoProjeto", "class_i_servico_projeto.html", [
      [ "CtrlServicoProjeto", "class_ctrl_servico_projeto.html", null ]
    ] ],
    [ "Nome", "class_nome.html", null ],
    [ "Papel", "class_papel.html", null ],
    [ "Pessoa", "class_pessoa.html", null ],
    [ "PlanoDeSprint", "class_plano_de_sprint.html", null ],
    [ "Prioridade", "class_prioridade.html", null ],
    [ "Projeto", "class_projeto.html", null ],
    [ "Senha", "class_senha.html", null ],
    [ "Tempo", "class_tempo.html", null ],
    [ "Texto", "class_texto.html", null ]
];