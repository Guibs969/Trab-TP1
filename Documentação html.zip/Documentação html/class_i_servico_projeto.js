var class_i_servico_projeto =
[
    [ "~IServicoProjeto", "class_i_servico_projeto.html#a902fb92e797c24d1a11c778d0a716487", null ],
    [ "atualizar", "class_i_servico_projeto.html#ad1c38dc208f2826f12ec45d766d1012a", null ],
    [ "buscar", "class_i_servico_projeto.html#a9c7233400d9679b71fc8eb3e9a72b01d", null ],
    [ "cadastrar", "class_i_servico_projeto.html#af6104eca58d51f7406df16f74b0841c2", null ],
    [ "excluir", "class_i_servico_projeto.html#ac5c31c96ab85c0c8e0bb8924df5a3557", null ],
    [ "existe", "class_i_servico_projeto.html#abd570aced05ae16abd11b7b27a3ff4d0", null ],
    [ "listar", "class_i_servico_projeto.html#a9fa59bf9d0f689b519d2ac002ae320f0", null ],
    [ "listarProjetosPorPessoa", "class_i_servico_projeto.html#ab086fa38a519c89d7ca1fada93369c6d", null ]
];