var class_plano_de_sprint =
[
    [ "adicionarHistoria", "class_plano_de_sprint.html#a592687b4da2eebde1939888c3b93c081", null ],
    [ "getCapacidade", "class_plano_de_sprint.html#a9a338492f7d18dada39014fd5c355cf4", null ],
    [ "getCodigo", "class_plano_de_sprint.html#ac2381fe1f2101f4982119a007573f67d", null ],
    [ "getCodigoProjeto", "class_plano_de_sprint.html#adc38c2a64cb4c7c18da376305737064b", null ],
    [ "getHistorias", "class_plano_de_sprint.html#a8f906687fd123a2072cb3e835a0cdd62", null ],
    [ "getObjetivo", "class_plano_de_sprint.html#a790aceecf2c79a63b974e97f1c04774f", null ],
    [ "removerHistoria", "class_plano_de_sprint.html#a4bac85d5631c53d735ac54296c160fa5", null ],
    [ "setCapacidade", "class_plano_de_sprint.html#ae3d25010275acc531274eda503ec1c33", null ],
    [ "setCodigo", "class_plano_de_sprint.html#a5e43c9da3b821e029055f6e4d824f52c", null ],
    [ "setCodigoProjeto", "class_plano_de_sprint.html#a49d45fe2c13d193db8a260be22e9ef45", null ],
    [ "setObjetivo", "class_plano_de_sprint.html#ada377021029a43d602e72370bb7e9503", null ]
];