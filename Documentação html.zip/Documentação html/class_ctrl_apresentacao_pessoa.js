var class_ctrl_apresentacao_pessoa =
[
    [ "executar", "class_ctrl_apresentacao_pessoa.html#aef0790349e2547e51916bd5895d2f21c", null ],
    [ "setServicoPessoa", "class_ctrl_apresentacao_pessoa.html#a89d06482d5368754a104e4859b509e9a", null ]
];