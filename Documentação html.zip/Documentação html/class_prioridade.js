var class_prioridade =
[
    [ "getValor", "class_prioridade.html#a0e8b94a8c528835653a59415ff437965", null ],
    [ "setValor", "class_prioridade.html#aad6b4a4481ac4b9096b7788b3b228e64", null ]
];