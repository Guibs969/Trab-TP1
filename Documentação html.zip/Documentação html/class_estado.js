var class_estado =
[
    [ "getValor", "class_estado.html#a5bd675fc2714dd7973602ead64895038", null ],
    [ "setValor", "class_estado.html#a33a4a941d8b83306f6793af42ed8ce66", null ]
];