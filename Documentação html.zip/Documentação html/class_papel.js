var class_papel =
[
    [ "getValor", "class_papel.html#a2f3d568dc6ddf7037c109f73f0726d72", null ],
    [ "setValor", "class_papel.html#a5b238a371095504639ba852f349ec1e4", null ]
];