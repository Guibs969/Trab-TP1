var class_i_servico_historia_usuario =
[
    [ "~IServicoHistoriaUsuario", "class_i_servico_historia_usuario.html#a33b86b17543460adf273e9710a07f189", null ],
    [ "alterarEstado", "class_i_servico_historia_usuario.html#a3dea3be7e2a1b3b9312f4eb91825edb4", null ],
    [ "atribuirDesenvolvedor", "class_i_servico_historia_usuario.html#a066f705391186774f28eb663204ef999", null ],
    [ "atualizar", "class_i_servico_historia_usuario.html#a17176d4a0e1801781e9326bdf6183fe1", null ],
    [ "buscar", "class_i_servico_historia_usuario.html#a0b4a39aa77539c8d01b6821eb1030069", null ],
    [ "cadastrar", "class_i_servico_historia_usuario.html#a751d47652ba629ab508f3c9e27a4ffb3", null ],
    [ "excluir", "class_i_servico_historia_usuario.html#a084a4310ad039dc09438c002b9e3f0d1", null ],
    [ "existe", "class_i_servico_historia_usuario.html#a0ec35dc93d7593eb978127347f240f4f", null ],
    [ "listar", "class_i_servico_historia_usuario.html#a926b1f0b5236d95976976296d2f1d72b", null ],
    [ "listarPorPessoa", "class_i_servico_historia_usuario.html#af435d68f93bce879e0441bfbb85f2c5f", null ],
    [ "listarPorPlano", "class_i_servico_historia_usuario.html#ac2db78453466d0e17605fe53fb4567a3", null ],
    [ "listarPorProjeto", "class_i_servico_historia_usuario.html#a20eb36425ebace89b832fab16a965071", null ],
    [ "removerDesenvolvedor", "class_i_servico_historia_usuario.html#a65212c2ad25f293ac40180c9c6247325", null ]
];