var class_projeto =
[
    [ "adicionarHistoria", "class_projeto.html#a292217d5d609469a1e9549594f996835", null ],
    [ "adicionarPlano", "class_projeto.html#a8f015c54c5d4349c61a6ab586fa863b1", null ],
    [ "getCodigo", "class_projeto.html#a5d9c3bb6177e5c62176347461bd620a3", null ],
    [ "getHistorias", "class_projeto.html#af8fe1e0455196a23acfe9abd22f039b7", null ],
    [ "getInicio", "class_projeto.html#ae68dfbb815e8a85340590eacc683e574", null ],
    [ "getMestreScrum", "class_projeto.html#a430aa302c35aad9b50184c665a594b1d", null ],
    [ "getNome", "class_projeto.html#a1eb1c0d356d0f662ac6fda75ff766004", null ],
    [ "getPlanos", "class_projeto.html#a619ceb2e1b8818e462ebe95bc33fa2dc", null ],
    [ "getProprietario", "class_projeto.html#a8e182dc90d52121b1851be1729664edf", null ],
    [ "getTermino", "class_projeto.html#aaa3ccd83ad23021458cac35b74683168", null ],
    [ "setCodigo", "class_projeto.html#adb1e1098e1f9d1eb23d3cb407c827988", null ],
    [ "setInicio", "class_projeto.html#a3bdcc2628e1e9923fc4365f0cc87d3dd", null ],
    [ "setMestreScrum", "class_projeto.html#a8596aac8aefd43f70b8679aedaa88289", null ],
    [ "setNome", "class_projeto.html#a653d8397857e75322e84fb346f150e37", null ],
    [ "setProprietario", "class_projeto.html#a6193e1e240318953eddbde1bae49eada", null ],
    [ "setTermino", "class_projeto.html#a65941701bfe67bdb761ae3f826f62cec", null ]
];