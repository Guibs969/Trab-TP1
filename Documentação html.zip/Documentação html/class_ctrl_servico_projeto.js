var class_ctrl_servico_projeto =
[
    [ "atualizar", "class_ctrl_servico_projeto.html#af25cf727db20a2315589d6cccef5c0fb", null ],
    [ "buscar", "class_ctrl_servico_projeto.html#ad26fd5a8b4f3d2423de3994fbbfefd46", null ],
    [ "cadastrar", "class_ctrl_servico_projeto.html#a9fe465554ba7f48d8f285d0deee9cb57", null ],
    [ "excluir", "class_ctrl_servico_projeto.html#a7d6feb75002c866e1c3c043baeb77782", null ],
    [ "existe", "class_ctrl_servico_projeto.html#a89191b67d71f16b4002c2244f7759e43", null ],
    [ "listar", "class_ctrl_servico_projeto.html#a11d36f907d3a07effc0b687ee7a72f7c", null ],
    [ "listarProjetosPorPessoa", "class_ctrl_servico_projeto.html#a1160e3f451d8ce070bf226806a68ba04", null ]
];